
  # Dashboard de Métricas da Newsletter

  This is a code bundle for Dashboard de Métricas da Newsletter. The original project is available at https://www.figma.com/design/9tJBixenx4jlrivlfEv7TT/Dashboard-de-M%C3%A9tricas-da-Newsletter.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  